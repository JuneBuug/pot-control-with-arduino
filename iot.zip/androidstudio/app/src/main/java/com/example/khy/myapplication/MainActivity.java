package com.example.khy.myapplication;

import android.content.Intent;
import android.graphics.Point;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

public class MainActivity extends AppCompatActivity {
    PopupWindow popup;
    View popupview;
    LinearLayout linear;

    PopupWindow popup_humidity;
    View popupview_humidity;
    LinearLayout linear_humidity;

    PopupWindow popup_light;
    View popupview_light;
    LinearLayout linear_light;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;

        linear = (LinearLayout)findViewById(R.id.temperature);
        popupview = View.inflate(this, R.layout.temperature, null);
        popup = new PopupWindow(popupview,width,height/3, true);
        linear.setOnClickListener(new LinearLayout.OnClickListener(){
            public void onClick(View v){
                // 가운데 아래 놓기
                popup.showAtLocation(linear, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM, 50,50);
            }
        });
        ImageButton btnclose = (ImageButton)popupview.findViewById(R.id.btnclose);
        btnclose.setOnClickListener(new ImageButton.OnClickListener() {
            public void onClick(View v){
                popup.dismiss();
            }
        });

        linear_humidity = (LinearLayout)findViewById(R.id.humidity);
        popupview_humidity = View.inflate(this, R.layout.humidity, null);
        popup_light = new PopupWindow(popupview_humidity,width,height/3, true);
        linear_humidity.setOnClickListener(new LinearLayout.OnClickListener(){
            public void onClick(View v){
                // 가운데 아래 놓기
                popup_light.showAtLocation(linear_humidity, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM, 50,50);
            }
        });
        btnclose = (ImageButton)popupview.findViewById(R.id.btnclose);
        btnclose.setOnClickListener(new ImageButton.OnClickListener() {
            public void onClick(View v){
                popup.dismiss();
            }
        });

        linear_light = (LinearLayout)findViewById(R.id.humidity);
        popupview_light = View.inflate(this, R.layout.humidity, null);
        popup_light= new PopupWindow(popupview_light,width,height/3, true);
        linear_light.setOnClickListener(new LinearLayout.OnClickListener(){
            public void onClick(View v){
                // 가운데 아래 놓기
                popup_humidity.showAtLocation(linear_light, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM, 50,50);
            }
        });
        btnclose = (ImageButton)popupview.findViewById(R.id.btnclose);
        btnclose.setOnClickListener(new ImageButton.OnClickListener() {
            public void onClick(View v){
                popup.dismiss();
            }
        });
    }

}
